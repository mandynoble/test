# BUG Template

## Expected Behaviour

## Actual Behaviour

## Steps to Reproduce
1.
1.
1.

## Versions
  - Authoring Tool Version:
  - Framework Version:
  - Operating System:
  - Browser:


# Feature Request Template

## Affected Area

## Requested Feature

## Use Case

## Current Workaround

## Additional Information