# Installation

You can find detailed instructions for installing the Adapt authoring tool on the [repository's wiki](https://github.com/adaptlearning/adapt_authoring/wiki/Installing-the-Authoring-Tool).
